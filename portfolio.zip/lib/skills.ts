type SkillType = 'JavaScript'
    | 'TypeScript'
    | 'Python'

    | 'React'
    | 'Next.js'
    | 'Gatsby'
    | 'Electron'
    | 'HTML'

    | 'Tailwind'
    | 'Chakra UI'
    | 'shadcn/ui'
    | 'CSS'
    | 'Bootstrap'
    
    | 'Jest'
    
    | 'MySQL'
    | 'MongoDB'
    | 'PostgreSQL'
    | 'Prisma'
    
    | 'Docker'
    | 'NPM Package'
    | 'Pusher'
    | 'AWS S3'
    | 'Uploadthing'