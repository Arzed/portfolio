export const WEBSITE_HOST_URL = "https://arzed.netlify.app";
